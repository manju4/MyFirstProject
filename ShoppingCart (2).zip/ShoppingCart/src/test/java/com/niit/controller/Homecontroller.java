package com.niit.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class Homecontroller<Http>

 {

	
	@RequestMapping("/")
	public String gotoHome()
	{
		return "index";
	}
	@RequestMapping("/login")
	public String login(Model m)
	{
		 m.addAttribute("userClickedLogin", true);
		return "login";
	}
	@RequestMapping("/register")
	public String register(Model m)
		{
			m.addAttribute("userClickedSignUp", true);
			return "register";
		}
	@RequestMapping("/validate")
	public String  validate(@RequestParam(name="userID") String id,
			@RequestParam(name="password") String pwd,
			Model model )
	{
		
		if(id.equals("niit")  && pwd.equals("niit"))
		{
			model.addAttribute("successmessage", "You successfully logged in");
		}
		else
		{
		   model.addAttribute("successmessage", " Invalid details.please try agin");	
		}
		return "index";	
	}
	
	@RequestMapping("/registertion")
	public String  register(@RequestParam(name="user Name") String name,
			@RequestParam(name="password") String  password,
			@RequestParam(name="email") String emailid,
			@RequestParam(name="user No") String tel,
			Model m )
	{
		
	
		
		if(name.equals("Manjunath")  && password.equals("manju414") 
			&& emailid.equals("manjunath@gmail.com") && tel.equals("962054545") )
		{
			m.addAttribute("registermessage", "You successfully Register");
		}
		else
		{
			m.addAttribute("registermessage", " Invalid details.please try agin");	
		}
		return "index";	
	}
	@RequestMapping("/product")
	public String product(Model mv)
	{
		 mv.addAttribute("userClickedNokia", true);
		 mv.addAttribute("userClickedLenovo", true);
		return "product";
	}
	
	@RequestMapping("/supplier")
	public String supplier(Model mv)
	{
		 mv.addAttribute("userClickedsupplier", true);
		return "supplier";
	}

}


