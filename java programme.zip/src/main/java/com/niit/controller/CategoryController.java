package com.niit.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcart.dao1.categorydao;
import com.niit.shoppingcart.model.categorymodel;
@Controller
public class CategoryController 
{
	Logger log=LoggerFactory.getLogger(CategoryController.class);
	  
	  @Autowired
	  private categorymodel categorymodel;
	  
	  @Autowired
	  private categorydao categoryDAO;
	  
	 // private String path=D:\\
	  
	  @RequestMapping(value="/category", method= RequestMethod.GET)
	  public String listCategories(Model model){
		  log.debug("Starting of listcategiries");
		  model.addAttribute("categorymodel", categorymodel);
		  model.addAttribute("categoryList", categoryDAO.list());
		  model.addAttribute("isAdminClickedCategory", "true");
		  log.debug("End of thelistcatrgories");
		  return "category";
	  }

	  @RequestMapping(value="/manage_category_add", method= RequestMethod.POST)
	  public String addCategory(@ModelAttribute("categorymodel") categorymodel categorymodel, Model model){
		  log.debug("Start of addCategory");
		  log.debug("id:" + categorymodel.getCategory_id());
		  if(categoryDAO.saveOrUpdate(categorymodel)==true){
			model.addAttribute("msg", "Successfully created/updated the category");  
		  }else{
			  model.addAttribute("msg", "not created for table from category");
		  }
		  model.addAttribute("categorymodel", categorymodel);
		  model.addAttribute("categoryList", categoryDAO.list());
		  model.addAttribute("isAdminClickedCategory", "true");
		  log.debug("End of addCategory");
		  return "category";
		  }
	  
	  @RequestMapping(value="manage_category_remove/{id}")
	  public String deleteCategory(@PathVariable("id") String id, Model model) throws Exception{

		  boolean flag =categoryDAO.delete(id);
		  String msg="Successfully done at the operation";
		  if(flag !=true){
			msg="The delete operation id not success" ; 
		  }
		  model.addAttribute("msg", msg);
		  return "category";
	  }
	  
	  @RequestMapping(value="manage_category_edit/{id}")
	  public String editCategory(@PathVariable("id") String id, Model model){
		  log.debug("Starting of editCategory");
		  
		  categorymodel=categoryDAO.get(id);
		  model.addAttribute("categorymodel", categorymodel);
		  log.debug("End of editCategory");
		  return "category";
	  }
}
