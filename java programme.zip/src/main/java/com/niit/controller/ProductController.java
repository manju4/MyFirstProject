package com.niit.controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.niit.shoppingcart.dao1.ProductDAO;
import com.niit.shoppingcart.model.Product;

@Controller
public class ProductController {
	 
	 
	@Autowired
	private ProductDAO productDAO;
	
	@Autowired
	private Product product;
	
	@RequestMapping(value = "/product", method = RequestMethod.GET)
	public String listProducts(Model model) {
		model.addAttribute("product", product);
		model.addAttribute("productList", productDAO.list());
/*		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
*/		model.addAttribute("isAdminClickedProduct", "true");
		return "product";
	}
	
	
	
	@RequestMapping(value = "/manage_product_add", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product product, Model model){
	
		if(productDAO.saveOrUpdate(product)==true){
		model.addAttribute("msg", "Successfully created/updated the product");  
	  }else{
		  model.addAttribute("msg", "not created for table from product");
	  }
	  model.addAttribute("product", product);
	  model.addAttribute("productList", productDAO.list());
	  model.addAttribute("isAdminClickedProduct", "true");
	  return "product";
}

@RequestMapping("manage_product_remove/{id}")
public String removeProduct(@PathVariable("id") String id, ModelMap model) throws Exception {

	  boolean flag =productDAO.delete(id);
	  String msg="Successfully done at the operation";
	  if(flag !=true){
		msg="The delete operation id not success" ; 
	  }
	  model.addAttribute("msg", msg);
	  return "product";

 }

		@RequestMapping("manage_product_edit/{id}")
		public String editProduct(@PathVariable("id") String id, Model model) {
			
			  product=productDAO.get(id);
			  model.addAttribute("product", product);
		/*	model.addAttribute("product", this.productDAO.get(id));
			model.addAttribute("listProducts", this.productDAO.list());
			model.addAttribute("categoryList", this.categoryDAO.list());
			model.addAttribute("supplierList", this.supplierDAO.list());*/
			return "product";
		}
		/*
		@RequestMapping(value = "product_get/{id}")
		public String getSelectedProduct(@PathVariable("id") String id, Model model,
				RedirectAttributes redirectAttributes) {
			redirectAttributes.addFlashAttribute("selectedProduct", productDAO.get(id));
			System.out.println("getting id");
			return "redirect:/backToHome";
		*/
		//}
		
		/*@RequestMapping(value = "/backToHome", method = RequestMethod.GET)
		public String backToHome(@ModelAttribute("selectedProduct") 
		        final Product selectedProduct, final Model model) */
		/*{
		
			model.addAttribute("selectedProduct", selectedProduct);
			//model.addAttribute("categoryList", this.categoryDAO.list());
		System.out.println("connected to back");
			return "index";
		}*/
}
