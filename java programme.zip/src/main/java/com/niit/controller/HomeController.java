package com.niit.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao1.SupplierDAO;
import com.niit.shoppingcart.dao1.categorydao;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.User;
import com.niit.shoppingcart.model.categorymodel;

@Controller
public class HomeController
{
		Logger log=LoggerFactory.getLogger(HomeController.class);
	
	  @Autowired
	  User user;
		   
	  
	  @Autowired
	  private Product product; //category list will load and set to session
	  	  
	  @Autowired
	  private categorymodel categorymodel;
	  
	  @Autowired
	  private categorydao categoryDAO;
	  
	  @Autowired
	  private Supplier supplier;
	  
	  @Autowired
	  private SupplierDAO supplierDAO;
	
		@RequestMapping("/")
		public ModelAndView onload (HttpSession session)
		{
			log.debug("Starting method of on Load");
			ModelAndView mv= new ModelAndView("home");
			session.setAttribute("categorymodel", categorymodel);
			session.setAttribute("Product", product);
			session.setAttribute("Supplier", supplier);
			
			session.setAttribute("categorymodelList", categoryDAO.list());
			session.setAttribute("supplierList", supplierDAO.list());
			
			log.debug("Ending method of on load");
			return mv;
		}
				
		@RequestMapping("/login")
		public ModelAndView loginHere()
		{
			log.debug("Starting method of loginHere");
			ModelAndView mv = new ModelAndView("login");
			mv.addObject("User",user);
			mv.addObject("isUserClickedloginHere", "true");
			log.debug("Ending method of loginHere");
			return mv;			
		}
		
		@RequestMapping("/register")
		public ModelAndView registerHere()
		{
			log.debug("Starting method of registerHere");
			ModelAndView mv=new ModelAndView("register");
			mv.addObject("User",user);
			mv.addObject("isUserClickedRegisterHere", "true");
			log.debug("Ending method of registerHere");
			return mv;
		}	
		
/*		@RequestMapping("/validate")
		public String validate(@RequestParam(name="userID") String id,
		       @RequestParam(name="password") String pwd,
		       Model model)
		       
		{
			//validate-hit the database to validate
			//niit
			
			if(id.equals("niit") && pwd.equals("niit"))
			{
				model.addAttribute("successmessage","you successfully logged in");				
			}
			else
			{
				model.addAttribute("successmessage","invalid details....please try again");				
			}
		//Sap
			return"home";
		}
		*/
}

