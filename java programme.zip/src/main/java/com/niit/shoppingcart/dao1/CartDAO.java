/*package com.niit.shoppingcart.dao1;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.Cart;
@Repository("cartDAO")
public interface CartDAO 
{	
	public boolean saveOrUpdate(Cart cart);
	
	public boolean update(Cart cart);
	
	public boolean delete(Cart cart);
	
	public Cart get (String id);

	public  List<Cart> list(String userId);

}
*/