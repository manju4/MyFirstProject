package com.niit.shoppingcart.dao1;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
*/import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.categorymodel;

@Repository("categoryDAO")
public   class categorydaoimpl implements categorydao

{
/*	private static Logger log= LoggerFactory.getLogger(categorydaoimpl.class);
*/	
@Autowired
private SessionFactory sessionFactory;

public categorydaoimpl(SessionFactory sessionFactory)
{
	this.sessionFactory=sessionFactory;
}


@Transactional	
	public boolean saveOrUpdate(categorymodel category) {
	
	try{
		
		sessionFactory.getCurrentSession().saveOrUpdate(category);
		return true ;
	}catch(HibernateException e) {
	
		e.printStackTrace();
		return false ;
	}
	

	}

	
	@Transactional	
	public boolean delete(String id)
	{
		
		try{	
			categorymodel category=get(id);
			sessionFactory.getCurrentSession().delete(category);
			return true;
		}catch(HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
		
		
	}
	@Transactional	
	public categorymodel get(String id) 
	{
		String hql="from categorymodel where category_id='"+id+"'";
		List<categorymodel> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		if(li==null||li.isEmpty())
		return null;
		else
		return li.get(0);
		
	}
	@Transactional	
	public List<categorymodel> list() 
	{
		String hql="from categorymodel ";
		List<categorymodel> ListCategory=sessionFactory.getCurrentSession().createCriteria(categorymodel.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return ListCategory;
	}
	
}

	
	
	
	


