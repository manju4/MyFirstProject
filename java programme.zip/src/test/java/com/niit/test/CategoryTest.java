package com.niit.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao1.categorydao;
import com.niit.shoppingcart.model.categorymodel;

public class CategoryTest {
	
	 

	public static void main(String[] args)
	{
	
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		categorydao categoryDAO = (categorydao) context.getBean("categoryDAO");
		categorymodel category = (categorymodel) context.getBean("categorymodel");
		
		 category.setCategory_id("My025");
		 category.setCategory_name("IPhone7");
		 category.setCategory_description("IPhone is now Iphone 7plus");

		 categoryDAO.saveOrUpdate(category);

		 category.setCategory_id("MOB050");
		 category.setCategory_name("IPhone9");
		 category.setCategory_description("IPhone stock is not available");
		 
		 categoryDAO.saveOrUpdate(category);
		 
		//category=categoryDAO.get("MOB050");
		//categoryDAO.delete(category);
		
		List<categorymodel> clist=categoryDAO.list();
		for(categorymodel c:clist)
		{
		System.out.println("Category name:"+c.getCategory_name());
		}
		
		System.out.println("Data inserted into DB");	
		
	}
		
}

	
	


