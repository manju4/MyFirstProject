package com.niit.test;


import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao1.ProductDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Product;

public class ProductTest {
	
	 

	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		Product product = (Product) context.getBean("product");
		

		
		
		 product.setId("PRT001");
		 product.setName("Mobile");
		 product.setPrice("RS 5999");
		 productDAO.saveOrUpdate(product);
	 
		 product.setId("RP002");
		 product.setName("Tab");
		 product.setPrice("RS 13999");
		 
		 
		 productDAO.saveOrUpdate(product);
		 
		product=productDAO.get("MOB050");
		productDAO.delete(product);
		
		List<Product> clist=productDAO.list();
		for(Product c:clist)
		{
		System.out.println("Cart name:"+c.getName());
		}		
		System.out.println("Data inserted into DB");	
		
	}
		
}
