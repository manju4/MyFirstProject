/*package com.niit.controller;

import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.net.jsse.openssl.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcart.dao1.CartDAO;
import com.niit.shoppingcart.dao1.ProductDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Product;

@Controller
public class CartController {

	@Autowired
	 private Cart cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	private ProductDAO productDAO;
	
	

	
	@RequestMapping(value = "/cart", method = RequestMethod.GET)
	public String myCart(Model model,HttpSession session) {
		model.addAttribute("cart", new Cart());
	String loggedInUserid=(String) session.getAttribute("loggedInUserid");
	if(loggedInUserid == null){
		Authentication dot= SecurityContextHolder.getContext().getAuthentication();
		loggedInUserid = dot.getName();	
	}
	
	int cartSize=cartDAO.list(loggedInUserid).size();
	
	if(cartSize==0){
		model.addAttribute("errorMessage", "Do you not have any product");
	}else{
		model.addAttribute("cartList", cartDAO.list(loggedInUserid));
		model.addAttribute("totalAmount", cartDAO.getTotalAmount(loggedInUserid)); 
		model.addAttribute("displayCart", "true");
		}
		return "home";
	}
	
	
	@RequestMapping(value = "/carts", method = RequestMethod.GET)
	public String listCarts(Model model) {
		model.addAttribute("cart", new Cart());
		model.addAttribute("cartList", this.cartDAO.list(null));
		return "cart";
	}
	
	
	//For add and update cart both
	@RequestMapping(value= "/cart/add/{id}", method = RequestMethod.GET)
	public String Mod addToCart(@PathVariable("id") String id, HttpSession session ){
		
	
	 Product product = productDAO.get(id);
	 Cart cart = new Cart();
	 cart.setPrice(product.getPrice());
	 cart.setProductName(product.getName());
	 String loggedInUserid=(String) session.getAttribute("loggedInUserid");
		if(loggedInUserid == null){
			Authentication dot= SecurityContextHolder.getContext().getAuthentication();
			loggedInUserid = dot.getName();	
		}//cart.setQuantity(1);
	 
		cart.setUserID("loggedInUserid"); 
	 cart.setStatus('N');
	// cart.setId(Thread LocalRandom.current().nextLong(100,1000000+1));
		cartDAO.save(cart);
		mo
		System.out.println("connected to cart");
		return "redirect:/onLoad";
		
	}
	
	@RequestMapping("cart/delete/{id}")
    public String deleteCart(@PathVariable("id") int id,Model model)
	{
	cartDAO.delete(id);
	return "redirect:/myCart";
       
    }
	
	
 
    @RequestMapping("cart/edit/{id}")
    public String editCart(@PathVariable("id") String id, Model model){
    	System.out.println("editCart");
        model.addAttribute("cart", this.cartDAO.get(id));
        model.addAttribute("listCarts", this.cartDAO.list());
        return "cart";
    }
    
    @RequestMapping(value = "/checkout")
	public String getcheckout ()
	{
		System.out.println(" Called..!");
		return "checkout";
	}
    
    @RequestMapping(value = "/checkout", method = RequestMethod.GET)
	public String checkout(Model model) {
	    
		int i,s=0,j=0;
		int n=cartDAO.list().size();
		System.out.println(n);
		for(i=0;i<n;i++)
		{
			s=s+cartDAO.list().get(i).getPrice();
			
		}
		System.out.println(s);
		model.addAttribute("sum", s);
		model.addAttribute("cart", new Category());
		model.addAttribute("cartList", this.cartDAO.list());
		//model.addAttribute("total", this.cartDAO.getTotalAmount("id"));
		
	
		
		//System.out.println(U);
		return "/checkout";
	}
    
    @RequestMapping(value = "/logout2", method = RequestMethod.GET)
	public String logout2(Model model) {
	
	
		//System.out.println(U);
		return "/logout";
	}

	@RequestMapping("/logout")
	public String logout(Model model)
	{
		int i,s=0,j=0;
		int n=cartDAO.list().size();
		System.out.println(n);
		for(i=0;i<n;i++)
		{
			s=s+cartDAO.list().get(i).getPrice();
			
		}
		System.out.println(s);
		model.addAttribute("sum", s);
		while(n!=0)
		{
			cartDAO.delete(cartDAO.list().get(j).getId());
			n=cartDAO.list().size();
			
		}
		return "logout";
	}
    
	}



*/