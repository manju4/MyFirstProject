package com.niit.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//import com.niit.shoppingcart.dao1.CartDAO;
import com.niit.shoppingcart.dao1.ProductDAO;
import com.niit.shoppingcart.dao1.SupplierDAO;
import com.niit.shoppingcart.dao1.UserDAO;
import com.niit.shoppingcart.dao1.categorydao;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.User;
import com.niit.shoppingcart.model.categorymodel;
import com.sun.javafx.sg.prism.NGShape.Mode;

public class UserController 
{
	Logger log=LoggerFactory.getLogger(UserController.class);


	 @Autowired
	   User user;
	  
	  @Autowired
	  UserDAO userDAO;	 
	  
	  @Autowired
	  private Cart cart;
	  
	  //@Autowired
//	  private CartDAO cartDAO;
	  
	  @Autowired
	  private Product product;
	  
	  @Autowired
	  private ProductDAO productDAO;
	  
	  @Autowired
	  private categorymodel categorymodel;
	  
	  @Autowired
	  private categorydao categoryDAO;
	  
	  @Autowired
	  private Supplier supplier;
	  
	  @Autowired
	  private SupplierDAO supplierDAO;
	  
	  @Autowired
	  private HttpSession session;
	  
	  @RequestMapping(value="/validate", method= RequestMethod.POST)
		public ModelAndView login(@RequestParam(value="userID") String userId,
		       @RequestParam(value="password") String password, HttpSession session)
	  {
		  
		ModelAndView mv=new ModelAndView("home");
		user=userDAO.isValidUser(userId,password);
		
		if(user !=null)
		{
			log.debug("Valid Credentials");
			user = userDAO.get(userId);
			session.setAttribute("loggedInUser", user.getName());
			session.setAttribute("loggedInUserID", user.getId());
			session.setAttribute("user", user);
			
			if(user.getRole().equals("ROLE_ADMIN"))
			{
				log.debug("logged as Admin");
				mv.addObject("isAdmin", true);
				session.setAttribute("supplier", supplier);
				session.setAttribute("supplier", supplierDAO.list());
				
				session.setAttribute("categorymodel", categorymodel);
				session.setAttribute("categorydao", categoryDAO.list());				
			} else{
				log.debug("Logged is user");
				mv.addObject("isAdmin", "false");
				/*cart=cartDAO.get(userId);
				mv.addObject("cart", cart);
				List<Cart> cartList = cartDAO.list(userId);
				mv.addObject("cartList", cartList);
				mv.addObject("cartSize", cartList.size());*/
			}
					
		}else{
			log.debug("Invalid Credentials");
			mv.addObject("invalidCredentials", "true");
			mv.addObject("errorMessage", "Invalid Credentials");
		}
		log.debug("Ending method of on login");
		return mv;
	  }
	  
	  @RequestMapping(value="/register", method=RequestMethod.POST)
	 public ModelAndView registerUser (@ModelAttribute User user)
	 {
		  log.debug("Starting of the method rehgisteruser");
		  ModelAndView mv= new ModelAndView("home");
		  if(userDAO.get(user.getId())==null);{
		  user.setRole("ROLE_USER");
		  userDAO.saveOrUpdate(user);
		  log.debug("Your are Successfully register");
		  mv.addObject("succesMessage", "You are successfully registered");
		  }{
			  log.debug("User exist with this id");
			  mv.addObject("errorMessage", "User exist with this id ");
		  }
		  log.debug("Ending with method of register");
		  return mv;
	 }
	 
	  @RequestMapping(value="/loginError", method=RequestMethod.GET)
	  public String loginError(Model model)
	  {
		log.debug("Starting of method of loginError"); 
		model.addAttribute("errorMessage", "Login error");
		log.debug("ending of method of loginError");
		return "home";
	  }

	  @RequestMapping(value="/accesDenied", method=RequestMethod.GET)
	  public String accesCDenied(Model model)
	  {
		log.debug("Starting of method of accesDenied"); 
		model.addAttribute("errorMessage", "Login error");
		log.debug("ending of method of accesDenied");
		return "home";
	  }
	

	  
	  
}
