package com.niit.shoppingcart.dao1;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.Cart;
@Repository("cartDAO")
public interface CartDAO 
{	
	public void save(Cart cart);
	
	public void update(Cart cart);
	
	public String delete(String id);
	
	//public Cart get (String id);

	public  List<Cart> list(String id);

	public Long getTotalAmount(String id);
	

}
