package com.niit.shoppingcart.dao1;

import java.util.List;
import java.util.Locale.Category;

import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.User;

@Repository("userDAO")
public  class UserDAOImpl implements UserDAO
{
/*	private static Logger log= LoggerFactory.getLogger(userdaoimpl.class);
*/	
@Autowired
private SessionFactory sessionFactory;
public UserDAOImpl(SessionFactory sessionFactory)
{
	this.sessionFactory=sessionFactory;
}

@Autowired
User user;

@Autowired
UserDAO userDAO;

@Transactional	
	public boolean saveOrUpdate(User user) {
	
	try{	
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		return false ;
	}catch(HibernateException e) {
	
		e.printStackTrace();
	}
	return false ;

	}

	
	@Transactional	
	public boolean delete(User user)
	{
		
		try{	
			sessionFactory.getCurrentSession().delete(user);
			return true;
		}catch(HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
		
		
	}
	@Transactional	
	public User get(String id) 
	{
		String hql="from User where id='"+id+"'";
		List<User> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		if(li==null||li.isEmpty())
		return null;
		else
		return li.get(0);
		
	}
	@Transactional
	public User isValidUser(String id, String password)
	{
		String hql="from User where id = " + "'" + id  + "'" + " and "
				+ "password = "  + "'" + password + "'";
		return getUserDetails(hql);
	}
	private User getUserDetails(String hql)
	{
		List<User> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		
		if( li ==null && li.isEmpty())
		return null;
		else
			return li.get(0);
	}

	@Transactional	
	public List<User> list() 
	{
		
		String hql="from User ";
		List<User> li=sessionFactory.getCurrentSession().createQuery(hql).list();

		return li;
	}	
}
