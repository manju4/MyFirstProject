package com.niit.shoppingcart.dao1;

import java.util.List;
import java.util.Locale.Category;

import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.Cart;

@Repository("cartDAO")
public  class CartDAOImpl implements CartDAO
{
	Logger log= LoggerFactory.getLogger(CartDAOImpl.class);
	@Autowired
	Cart cart;
	
	@Autowired
	CartDAO cartDAO;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public CartDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	public  CartDAOImpl()
	{
	}
	

	@Transactional	
	public List<Cart> list(String id) 
	{
		String hql="from Cart where userId='" + id + "'" +" and status="+"'N'";
		List<Cart> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		return li;
	}

	/*@Transactional
	public void save(String id) {
		cart.setId(getMaxId());;
		sessionFactory.getCurrentSession().save(cart);
	}*/
	
	@Transactional	
	public void update(Cart cart)
	{
			sessionFactory.getCurrentSession().update(cart);
	}

	private  long getMaxId() {
		
		Long maxID =100L;
		try {
			String hql= "select max(id) from Cart";
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			maxID=(Long) query.unwrap(null);
		} catch (HibernateException e) {
			maxID=100L;
			e.printStackTrace();
		}
		return maxID+1;
		
	}

	@Transactional
	public String delete(String id) {
		Cart cart=new Cart();
		cart.setId(id);
	try {
		sessionFactory.getCurrentSession().delete(cart);
	} catch (HibernateException e) {
		e.printStackTrace();
		return e.getMessage();
	}
		return null;
	}

	@Transactional
	public Long getTotalAmount(String id) 
	{
		String hql="select sum(price) from Cart where userID=" + "'" + id + "'" +" and status="+"'N'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		Long sum= (Long) query.unwrap(null);
		return sum;
	}
	@Transactional
	public void save(Cart cart) {
		cart.setId(getMaxId());;
		sessionFactory.getCurrentSession().save(cart);	
	}	

}
