/*package com.niit.shoppingcart.dao1;

import com.niit.shoppingcart.model.Order;

public interface OrderDAO 
{
	public boolean saveOrUpdate(Order order);

}
*/