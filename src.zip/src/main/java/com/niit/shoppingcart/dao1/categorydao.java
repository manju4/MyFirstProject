package com.niit.shoppingcart.dao1;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.categorymodel;
@Repository("categoryDAO")
public interface categorydao {
	
	public boolean saveOrUpdate(categorymodel category);
	
	/*public boolean update(Category category);*/
	
	public boolean delete(String id);
	
	public categorymodel get (String id);

	public  List<categorymodel> list();
}
