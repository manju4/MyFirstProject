package com.niit.shoppingcart.dao1;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.User;

@Repository("userDAO")
public interface UserDAO 
{
	public boolean saveOrUpdate(User user);
	
	/*public boolean update(Category user);*/
	
	public boolean delete(User user);
	
	public User get (String id);

	public  List<User> list();
	
	public User isValidUser(String id, String password) ;
		
	
}
