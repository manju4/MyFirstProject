package com.niit.shoppingcart.model;

import java.io.Serializable;

public class Order implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String userID;
	
	private String orderID;
	
	private ShippingAddress shippingAddress;
	
	private BillingAddress billingAddress;
	
	//private MyCart myCart;
	
	private long totalAmount;
	
	//private String 

	
	
		
	
}
