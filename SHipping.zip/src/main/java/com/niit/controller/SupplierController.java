package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcart.dao1.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

@Controller
public class SupplierController {

	@Autowired
	private SupplierDAO supplierDAO;
	
	@Autowired
	private Supplier supplier;
	
	@RequestMapping(value = "/supplier", method = RequestMethod.GET)
	public String listSuppliers(Model model) {
		model.addAttribute("supplier", supplier);
		model.addAttribute("supplierList",supplierDAO.list());
		model.addAttribute("isAdminClickedSupplier", "true");
		return "supplier";
	}
	
	@RequestMapping(value = "/manage_supplier_add", method = RequestMethod.POST)
	public String addSupplier(@ModelAttribute("supplier") Supplier supplier, Model model) {
		if(supplierDAO.saveOrUpdate(supplier)==true){
			model.addAttribute("msg","Successfully created/updated the supplier");  
		  }else{
			  model.addAttribute("msg", "not created for table from supplier");
		  }
		
		//model.addAttribute("supplier", supplier);
		model.addAttribute("supplierList", supplierDAO.list());
		model.addAttribute("isAdminClickedSupplier", "true");
		return "supplier";		
	}
	
	@RequestMapping("manage_supplier_remove/{id}")
	public String deleteSupplier(@PathVariable("id") String id, Model model) throws Exception {

		  boolean flag =supplierDAO.delete(id);
		  String msg="Successfully done at the operation";
		  if(flag !=true){
			msg="The delete operation id not success" ; 
		  }
		  model.addAttribute("msg", msg);
		  return "supplier";
		}

		@RequestMapping("manage_supplier_edit/{id}")
		public String editSupplier(@PathVariable("id") String id, Model model) {
			  supplier=supplierDAO.get(id);
			  model.addAttribute("supplier", supplier);
			  return "supplier";
		}
}
