/*package com.niit.test;


import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao1.SupplierDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Supplier;

public class SupplierTest {
	
	 

	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
		Supplier supplier = (Supplier) context.getBean("supplier");
		

		
		
		 supplier.setId("Sup001");
		 supplier.setName("Sham");
		 supplier.setAddress("Maleshwarm");
		 supplierDAO.saveOrUpdate(supplier);

		 
		 supplier.setId("Sup002");
		 supplier.setName("John");
		 supplier.setAddress("Rajajinagar");
		
		 supplierDAO.saveOrUpdate(supplier);
		 

		 supplier.setId("Sup003");
		 supplier.setName("Jon");
		 supplier.setAddress("Rajajinagar");
		
		 supplierDAO.saveOrUpdate(supplier); 
		 
		supplier=supplierDAO.get("Sup002");
		supplierDAO.delete(supplier);
		
		 List<Supplier> clist=supplierDAO.list();
			for(Supplier c:clist)
			{
			System.out.println("Supplier name:"+c.getName());
			}		
		System.out.println("Data inserted into DB");	
		
	}
		
}
*/