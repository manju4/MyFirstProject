/*package com.niit.shoppingcart.webflow;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.niit.shoppingcart.dao1.OrderDAO;
import com.niit.shoppingcart.model.BillingAddress;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Order;
import com.niit.shoppingcart.model.PaymentMethod;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.ShippingAddress;
import com.niit.shoppingcart.model.User;

@Component
public class OrderWebflow 
{
	@Autowired
	private ShippingAddress shippingAddress;
	
	@Autowired
	private BillingAddress billingAddress;
	
	@Autowired
	private User user;
	
	@Autowired
	  Cart cart;
	
	
	@Autowired
	private OrderDAO orderDAO;
	
	@Autowired
	Order order ;
	
	
	@Autowired
	 HttpSession httpSession;
	
	@Autowired
	 Product product;
	
	public Order initFlow(){
	
		order= new Order();
		return order;
	}
	
	public String addShippingAddress(Order order,ShippingAddress shippingAddress){
		order.setShippingAddress(shippingAddress);
		return"sucess";
	}
	
	public String addBillingAddress(Order order,BillingAddress billingAddress){
		order.setBillingAddress(billingAddress);
		return"sucess";
	}

	public String addPaymentMethod(Order order,PaymentMethod paymentMethod){
		order.setPaymentMethod(paymentMethod.getPaymentMethod());
		
		this.confirmOrder(order);
		return"sucess";
	}

	
	public String confirmOrder(Order order){
		orderDAO.saveOrUpdate(order);
		return"sucess";
	}
	
	


}
*/