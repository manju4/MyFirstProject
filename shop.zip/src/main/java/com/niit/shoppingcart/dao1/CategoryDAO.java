package com.niit.shoppingcart.dao1;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.Category;

@Repository("categoryDAO")
public interface CategoryDAO {

	public List<Category> list();
	public Category get(String id);
	public Category getByName(String name);
	public boolean saveOrUpdate(Category category);
	public boolean delete(String id);

}
