/*package com.niit.shoppingcart.dao1;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("orderDAO")
public class OrderDAOImpl  implements OrderDAO
{
	@Autowired
	private SessionFactory sessionFactory;

	public OrderDAOImpl(SessionFactory sessionFactory)
	{
	this.sessionFactory=sessionFactory;
	}


		@Transactional	
		public void saveOrUpdate(Order order)
		{
	
			sessionFactory.getCurrentSession().saveOrUpdate(order);
		}	
}
*/