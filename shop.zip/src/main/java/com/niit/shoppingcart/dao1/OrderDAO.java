/*package com.niit.shoppingcart.dao1;

public interface OrderDAO
{
	public void saveOrUpdate(Order order);

}
*/