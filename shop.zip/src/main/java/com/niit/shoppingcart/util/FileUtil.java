/*package com.niit.shoppingcart.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import org.springframework.web.multipart.MultipartFile;

public class FileUtil 
{

	public static void upload(String path,MultipartFile file, String filename) {
		if(!file.isEmpty())
		{
		
				try{
					byte[] bytes = file.getBytes();
					//creating directort to store file
					File dir = new File(path);
					if(!dir.exists())
						dir.mkdirs();
					//create file on server
					//F:\\shoppingcart\\images\\filename.jpg
					File serverFile = new File(dir.getAbsolutePath() 
							+ File.separator+filename);
					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
					stream.write(bytes);
					stream.close();
				}catch(Exception e){
					e.printStackTrace();
				}}
		}	
}

*/