package com.niit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcart.dao1.CategoryDAO;
import com.niit.shoppingcart.dao1.ProductDAO;
import com.niit.shoppingcart.dao1.SupplierDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.User;


@Controller
public class ProductController 
{
	@Autowired(required = true)
	private ProductDAO productDAO;
	
	@Autowired
	private Product product;
	
	@Autowired(required = true)
	private CategoryDAO categoryDAO;
	
	@Autowired
	private Category category;
	
	@Autowired(required = true)
	private SupplierDAO supplierDAO;
	
	@Autowired
	private Supplier supplier;
	
	@RequestMapping(value = "/product", method = RequestMethod.GET)
	public String listProducts(Model model) {
		model.addAttribute("product", product);
		model.addAttribute("productList",productDAO.list());
		model.addAttribute("categoryList",categoryDAO.list());
		model.addAttribute("supplierList", supplierDAO.list());
		model.addAttribute("isAdminClickedProduct", "true");
		return "product";
	}
	
	/*  
	 @ModelAttribute("product")
	 public Product createModel() 
	 {
	      return new Product();
	  }
	  */
	  
	@RequestMapping(value = "/manage_product_add", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product product, Model model) {
		/*category=categoryDAO.getByName(product.getCategory().getCategory_name());
		supplier=supplierDAO.getByName(product.getSupplier().getSupplier_name());
		
		categoryDAO.saveOrUpdate(category);
		supplierDAO.saveOrUpdate(supplier);
		
		product.setCategory(category);
		product.setSupplier(supplier);
		
		product.setCategory_id(category.getCategory_id());
		product.setSupplier_id(supplier.getSupplier_id());*/
		
		if(productDAO.saveOrUpdate(product)==true){
			model.addAttribute("msg","Successfully created/updated the product");  
		  }else{
			  model.addAttribute("msg", " product not added to the table");
		  }
		
		model.addAttribute("product", product);
		model.addAttribute("productList", productDAO.list());
		model.addAttribute("isAdminClickedproduct", "true");
		return "product";		
	}
	
	@RequestMapping("manage_product_delete/{id}")
	public String deletePoroduct(@PathVariable("id") String id, Model model) throws Exception 
	{

	  boolean flag =productDAO.delete(id);
		  String msg="Successfully done at the operation";
		  if(flag !=true){
			msg="The delete operation id not success" ; 
		  }
		  model.addAttribute("msg", msg);
		
		  //productDAO.get(id);
		  return "redirect:/product";
	}

		@RequestMapping("manage_product/edit/{id}")
		public String editProduct(@PathVariable("id") String id, Model model) {
			  product=productDAO.get(id);
			  model.addAttribute("selectedProduct", product);
			  return "redirect:/product";
		}

	


}
