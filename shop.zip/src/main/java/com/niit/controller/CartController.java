/*package com.niit.controller;

import java.util.concurrent.ThreadLocalRandom;

import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.net.jsse.openssl.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao1.CartDAO;
import com.niit.shoppingcart.dao1.ProductDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;

@Controller
public class CartController {

	@Autowired
	 private Cart cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	private ProductDAO productDAO;
	
	

	
	@RequestMapping(value = "/cart", method = RequestMethod.GET)
	public ModelAndView addtoCart(String id,HttpSession session) {
	
		Product product=productDAO.get(id);
		cart.setPrice(product.getprice());
		String loggedInUserid=(String) session.getAttribute("loggedInUserid");
	if(loggedInUserid == null){
		Authentication dot= SecurityContextHolder.getContext().getAuthentication();
		loggedInUserid = dot.getName();	
	}
	
	int cartSize=cartDAO.list(loggedInUserid).size();
	
	if(cartSize==0){
		model.addAttribute("errorMessage", "Do you not have any product");
	}else{
		model.addAttribute("cartList", cartDAO.list(loggedInUserid));
		model.addAttribute("totalAmount", cartDAO.getTotalAmount(loggedInUserid)); 
		model.addAttribute("displayCart", "true");
		}
		return "home";
	}

	@RequestMapping(value = "/cart", method = RequestMethod.GET)
	public String cart(Model model,HttpSession session) {
		model.addAttribute("cart",new Cart());
		
		String loggedInUserid=(String) session.getAttribute("loggedInUserid");
		if(loggedInUserid == null){
			Authentication dot= SecurityContextHolder.getContext().getAuthentication();
			loggedInUserid = dot.name();	
		}
		int cartSize=cartDAO.list(loggedInUserid).size();
		
		if(cartSize==0){
			model.addAttribute("errorMessage", "Do you not have any product");
		}else{
			model.addAttribute("cartList", cartDAO.list(loggedInUserid));
			model.addAttribute("totalAmount", cartDAO.getTotalAmount(loggedInUserid)); 
			model.addAttribute("displayCart", "true");
			}
			return "home";
		}	
	
	@RequestMapping(value= "/cart/add/{id}", method = RequestMethod.GET)
	public ModelAndView addToCart(@PathVariable("id") String id, HttpSession session){
		
	
	 Product product = productDAO.get(id);
	 cart.setPrice(product.getprice());
	 cart.setProductName(product.getName());
	 String loggedInUserid=(String) session.getAttribute("loggedInUserid");
		if(loggedInUserid == null){
			Authentication dot= SecurityContextHolder.getContext().getAuthentication();
			loggedInUserid = dot.name();	
		}	 
	 cart.setId("loggedInUserid"); 
	 cart.setStatus('N'); 
	 System.out.println("connect to cart");
	 cart.setId(ThreadLocalRandom.current().nextLong(100,100000+1));
		cartDAO.saveOrUpdate(cart);
		ModelAndView mv= new  ModelAndView("redirect:/home");
		mv.addObject("suceessMessage", "Successfully added to the cart");
		System.out.println("connected to cart");
		return mv;
		
	}
	@RequestMapping("cart/delete/{id}")
    public String deleteCart(@PathVariable("id") String id,Model model){
	try {
		cartDAO.delete(id);
		model.addAttribute("message", "Successsfully removed ");
	} catch (Exception e) {
		model.addAttribute("message", e.getMessage());
		e.printStackTrace();
	}
	return "redirect:/home";
       
    }
	
	}



*/