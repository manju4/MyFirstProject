package com.niit.test;


//import java.util.List;
//
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//
//import com.niit.shoppingcart.dao1.CartDAO;
//import com.niit.shoppingcart.model.Cart;
//import com.niit.shoppingcart.model.categorymodel;

//public class CartTest {
//	
//	 
//
//	public static void main(String[] args) {
//		
//		
//		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
//		context.scan("com.niit");
//		context.refresh();
//		
//		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
//		Cart cart = (Cart) context.getBean("cart");
//		
//
//		
//		
//		 cart.setId("Cart004");
//		 cart.setOrder_id("Or564321");
//		 cart.setPayment_method("Cash and delivery");
//		 cart.setBilling_address_id("12345");
//		 cart.setShipping_address_id("address");
//		 
//
//		 cartDAO.saveOrUpdate(cart);
//
//		 cart.setId("Cart002");
//		 cart.setOrder_id("Or564322");
//		 cart.setPayment_method("Fast cash");
//		 cart.setBilling_address_id("12589");
//		 cart.setShipping_address_id("shipping");
//		 
//		 cartDAO.saveOrUpdate(cart);
//
//		 
//		 cart.setId("Cart003");
//		 cart.setOrder_id("Or564322");
//		 cart.setPayment_method("Fast cash");
//		 cart.setBilling_address_id("12589");
//		 cart.setShipping_address_id("shipping");
//		 
//		 cartDAO.saveOrUpdate(cart);
//		 
//		cart=cartDAO.get("Cart002");
//		cartDAO.delete(cart);
//		
//		
//		List<Cart> clist=cartDAO.list();
//		for(Cart c:clist)
//		{
//		System.out.println("Cart name:"+c.getOrder_id());
//		}
//		
//		System.out.println("Data inserted into DB");
//	}
//		
//}