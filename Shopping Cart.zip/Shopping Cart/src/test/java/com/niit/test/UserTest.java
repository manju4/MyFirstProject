package com.niit.test;


import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.impl.UserDAOImpl;
import com.niit.shoppingcart.dao1.UserDAO;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.User;

public class UserTest {
	
	 

	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		User user = (User) context.getBean("user");
		

		
		
		 user.setId("Us001");
		 user.setName("Hello");
		 user.setPassword("my56897");
		 user.setContact("9654765412");
		 user.setMail("manju414@gmail.com");
		 user.setRole("user");
		 userDAO.saveOrUpdate(user);
//
//		 user.setId("Us002");
//		 user.setName("World");
//		 user.setPassword("89745");
//		 
//		
//		 userDAO.saveOrUpdate(user);
//		 
//		user=userDAO.get("Us002");
//		userDAO.delete(user);
//		
		 List<User> clist=userDAO.list();
			for(User c:clist)
			{
			System.out.println("User name:"+c.getName());
			}		
		System.out.println("Data inserted into DB");	
		
	}
		
}
