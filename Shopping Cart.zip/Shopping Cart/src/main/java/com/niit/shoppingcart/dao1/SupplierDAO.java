package com.niit.shoppingcart.dao1;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.Supplier;
@Repository("supplierDAO")
public interface SupplierDAO 
{
	public boolean saveOrUpdate(Supplier supplier);
	
	/*public boolean update(Category supplier);*/
	
	public boolean delete(Supplier supplier);
	
	public Supplier get (String id);

	public  List<Supplier> list();
}
