package com.niit.shoppingcart.dao.impl;

import java.util.List;
import java.util.Locale.Category;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao1.CartDAO;
import com.niit.shoppingcart.model.Cart;

@Repository("cartDAO")
public  class CartDAOImpl implements CartDAO

{
/*	private static Logger log= LoggerFactory.getLogger(cartdaoimpl.class);
*/	
@Autowired
private SessionFactory sessionFactory;
public CartDAOImpl(SessionFactory sessionFactory)
{
	this.sessionFactory=sessionFactory;
}

@Autowired
Cart cart;

@Autowired
CartDAO cartDAO;

@Transactional	
	public boolean saveOrUpdate(Cart cart) {
	
	try{	
		sessionFactory.getCurrentSession().saveOrUpdate(cart);
		return false ;
	}catch(HibernateException e) {
	
		e.printStackTrace();
		return false ;
	}

	}

	public boolean update(Cart cart)
	{
		try{	
			sessionFactory.getCurrentSession().delete(cart);
			return true;
		}catch(HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
	}
	@Transactional	
	public boolean delete(Cart cart)
	{
		
		try{	
			sessionFactory.getCurrentSession().delete(cart);
			return true;
		}catch(HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
		
		
	}
	@Transactional	
	public Cart get(String id) 
	{
		String hql="from Cart where id='"+id+"'";
		List<Cart> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		if(li==null||li.isEmpty())
		return null;
		else
		return li.get(0);
		
	}
	@Transactional	
	public List<Cart> list() 
	{
		
		String hql="from Cart ";
		List<Cart> li=sessionFactory.getCurrentSession().createQuery(hql).list();

		return li;
	}	

}
