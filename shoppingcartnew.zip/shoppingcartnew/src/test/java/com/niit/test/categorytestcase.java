package com.niit.test;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao1.categorydao;
import com.niit.shoppingcart.model.categorymodel;

public class categorytestcase 
{


		
		@Autowired
		static
		AnnotationConfigApplicationContext context;

		@Autowired
		static	
		categorydao categoryDAO;		
		
		@Autowired
		static
		categorymodel category;
		
		@BeforeClass
		public static void init()
		{
		context = new 	AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();	
		
		categoryDAO = (categorydao) context.getBean("categoryDAO");

		
		category = (categorymodel) context.getBean("category");
		
		}
		
		@Test
		public void createcategorytestcase()
		{
		
			category.setId("VWN023");
			category.setName("Mi5S");
			category.setDescription("Awesome");
			
			boolean status=categoryDAO.saveOrUpdate(category);
		
			Assert.assertEquals("create category test", true,status);
				
		}
		
		
//		@Test
//		public void updatecategoryTestCase(){
//			
//			category.setCat_id("MOB001");
//			category.setCat_name("iPhone7 Pluse");
//			category.setDescription("An  iPhone is an iPhone");
//			
//			Assert.assertEquals("Update category",true,categoryDAO.update(category));
//		}
//		
		
//		@Test
//		public void deletecategoryTestCase()
//		{			
//		category.setId("");
//		Assert.assertEquals("Delete category", true, categoryDAO.delete("category") );
//		}
//		
//		
//		@Test
//		public void getcategoryTestCase()
//		{
//			Assert.assertEquals("Get category", true,categoryDAO.get("Mob001"));
//		}
//		
//		
//		@Test
//		public void listcategoryTestCase()
//		{
//			Assert.assertEquals("List category",	5 ,categoryDAO.list().size());
//		}
//
//
}



