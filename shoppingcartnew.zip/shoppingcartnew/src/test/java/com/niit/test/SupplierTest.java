package com.niit.test;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao1.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

public class SupplierTest {
	
	 

	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
		Supplier supplier = (Supplier) context.getBean("supplier");
		

		
		
		 supplier.setId("Sup001");
		 supplier.setName("Sham");
		 supplier.setAddress("Maleshwarm");
		 
		 supplier.setId("Sup002");
		 supplier.setName("John");
		 supplier.setAddress("Rajajinagar");
		
		 supplierDAO.saveOrUpdate(supplier);
		 
		//supplier=supplierDAO.get("MOB050");
		//supplierDAO.delete(supplier);
		
		//supplier=supplierDAO.list("MOB006");
		
		System.out.println("Data inserted into DB");	
		
	}
		
}
