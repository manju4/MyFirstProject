package com.niit.shoppingcart.dao1;

import java.util.List;

import com.niit.shoppingcart.model.User;

public interface UserDAO 
{
	public boolean saveOrUpdate(User user);
	
	/*public boolean update(Category user);*/
	
	public boolean delete(User user);
	
	public User get (String id);

	public  List<User> list();
}
