package com.niit.shoppingcart.dao1;

import java.util.List;

import com.niit.shoppingcart.model.categorymodel;

public interface categorydao {
	
	public boolean saveOrUpdate(categorymodel category);
	
	/*public boolean update(Category category);*/
	
	public boolean delete(categorymodel category);
	
	public categorymodel get (String id);

	public  List<categorymodel> list();
}
