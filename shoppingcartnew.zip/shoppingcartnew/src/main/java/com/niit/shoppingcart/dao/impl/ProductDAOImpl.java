package com.niit.shoppingcart.dao.impl;

import java.util.List;
import java.util.Locale.Category;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao1.ProductDAO;
import com.niit.shoppingcart.model.Product;

@Repository("productDAO")
public  class ProductDAOImpl implements ProductDAO

{
/*	private static Logger log= LoggerFactory.getLogger(productdaoimpl.class);
*/	
@Autowired
private SessionFactory sessionFactory;
public ProductDAOImpl(SessionFactory sessionFactory)
{
	this.sessionFactory=sessionFactory;
}

@Autowired
Product product;

@Autowired
ProductDAO productdao;

@Transactional	
	public boolean saveOrUpdate(Product product) {
	
	try{	
		sessionFactory.getCurrentSession().saveOrUpdate(product);
		return false ;
	}catch(HibernateException e) {
	
		e.printStackTrace();
	}
	return false ;

	}

	@Transactional	
	public boolean delete(Product product)
	{
		
		try{	
			sessionFactory.getCurrentSession().delete(product);
			return true;
		}catch(HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
		
		
	}
	@Transactional	
	public Product get(String id) 
	{
		String hql="from Product where id='"+id+"'";
		List<Product> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		if(li==null||li.isEmpty())
		return null;
		else
		return li.get(0);
		
	}
	@Transactional	
	public List<Product> list() 
	{
		
		String hql="from Product ";
		List<Product> li=sessionFactory.getCurrentSession().createQuery(hql).list();

		return list();
	}	
}
