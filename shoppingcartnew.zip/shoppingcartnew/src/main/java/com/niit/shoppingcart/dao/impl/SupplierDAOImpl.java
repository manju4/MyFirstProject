package com.niit.shoppingcart.dao.impl;

import java.util.List;
import java.util.Locale.Category;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao1.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

@Repository("supplierDAO")
public  class SupplierDAOImpl implements SupplierDAO

{
/*	private static Logger log= LoggerFactory.getLogger(supplierdaoimpl.class);
*/	
@Autowired
private SessionFactory sessionFactory;
public SupplierDAOImpl(SessionFactory sessionFactory)
{
	this.sessionFactory=sessionFactory;
}

@Autowired
Supplier supplier;

@Autowired
SupplierDAO supplierdao;

@Transactional	
	public boolean saveOrUpdate(Supplier supplier) {
	
	try{	
		sessionFactory.getCurrentSession().saveOrUpdate(supplier);
		return false ;
	}catch(HibernateException e) {
	
		e.printStackTrace();
	}
	return false ;

	}

	
	@Transactional	
	public boolean delete(Supplier supplier)
	{
		
		try{	
			sessionFactory.getCurrentSession().delete(supplier);
			return true;
		}catch(HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
		
		
	}
	@Transactional	
	public Supplier get(String id) 
	{
		String hql="from Supplier where id='"+id+"'";
		List<Supplier> li=sessionFactory.getCurrentSession().createQuery(hql).list();
		if(li==null||li.isEmpty())
		return null;
		else
		return li.get(0);
		
	}
	@Transactional	
	public List<Supplier> list() 
	{
		
		String hql="from Supplier ";
		List<Supplier> li=sessionFactory.getCurrentSession().createQuery(hql).list();

		return list();
	}		
}
