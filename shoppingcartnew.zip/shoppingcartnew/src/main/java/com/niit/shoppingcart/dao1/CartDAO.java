package com.niit.shoppingcart.dao1;

import java.util.List;

import com.niit.shoppingcart.model.Cart;

public interface CartDAO 
{	
	public boolean saveOrUpdate(Cart cart);
	
	/*public boolean update(Category cart);*/
	
	public boolean delete(Cart cart);
	
	public Cart get (String id);

	public  List<Cart> list();

}
